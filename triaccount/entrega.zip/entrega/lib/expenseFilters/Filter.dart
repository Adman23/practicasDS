abstract class Filter {
  void execute(Map<String, dynamic> request);
}
