class Api::MembershipController < ApplicationController
end
