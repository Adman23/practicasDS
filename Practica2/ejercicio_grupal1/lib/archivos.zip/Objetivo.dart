import 'Correo.dart';

class Objetivo {
  void string(Correo correo) {
    print("El correo es ${correo.email}, ${correo.password}");
  }
}