class Correo {
  final String email;
  final String password;

  Correo(this.email, this.password);
}
