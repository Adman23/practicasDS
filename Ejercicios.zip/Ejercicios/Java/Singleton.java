public class Singleton {
    private static Singleton instance;
    private String coffeeType;

    private Singleton(String coffeeType) {
        this.coffeeType = coffeeType;
    }

    public static Singleton getInstance(String coffeeType) {
        if (instance == null) {
            instance = new Singleton(coffeeType);
        }
        return instance;
    }

    public String prepare() {
        return "Preparing a " + coffeeType;
    }
}
