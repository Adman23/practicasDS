import java.util.ArrayList;

class HumanDNA implements Cloneable {
    private ArrayList<String> geneticCode;

    public HumanDNA() {
        this.geneticCode = new ArrayList<>();
    }

    @Override
    protected HumanDNA clone() {
        try {
            HumanDNA copy = (HumanDNA) super.clone();
            copy.geneticCode = new ArrayList<>(this.geneticCode);
            return copy;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }

    public void mutateGeneticCode(String mutation) {
        this.geneticCode.add(mutation);
    }

    public String toString() {
        return "Genetic Code: " + this.geneticCode;
    }
}
