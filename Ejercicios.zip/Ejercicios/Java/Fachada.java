class SistemaInventario {
    public boolean verificarDisponibilidad(int producto_id) {
        System.out.println("Verificando la disp. de " + producto_id);
        return true;
    }
}

class SistemaPagos {
    public boolean procesarPagos(int tarjeta_numero, int monto) {
        System.out.println("Pago con tarjeta " + tarjeta_numero + " " + monto);
        return true;
    }
}

class SistemaEnvios {
    public boolean programarEnvio(String direccion) {
        System.out.println("Programando envio a " + direccion);
        return true;
    }
}

class Fachada {
    private SistemaInventario inventario = new SistemaInventario();
    private SistemaPagos pagos = new SistemaPagos();
    private SistemaEnvios envios = new SistemaEnvios();

    public void procesarOrden(int producto_id, int tarjeta_numero, int monto, String direccion) {
        if(inventario.verificarDisponibilidad(producto_id)) {
            if(pagos.procesarPagos(tarjeta_numero, monto)) {
                envios.programarEnvio(direccion);
                System.out.println("Orden procesada exitosamente");
            }
            else {
                System.out.println("El pago no pudo ser procesado");
            }
        }
        else {
            System.out.println("Producto no disponible");
        }
    }
}