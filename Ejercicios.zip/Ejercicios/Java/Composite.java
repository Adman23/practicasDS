import java.util.ArrayList;

interface Componente {
    void mostrar();
}

class Archivo implements Componente {
    private String nombre;

    public Archivo(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public void mostrar() {
        System.out.println("Archivo: " + nombre);
    }
}

class Carpeta implements Componente {
    private String nombre;
    private ArrayList<Componente> hijos = new ArrayList<>();

    public Carpeta(String nombre) {
        this.nombre = nombre;
    }

    public void agregar(Componente componente) {
        hijos.add(componente);
    }

    public void remover(Componente componente) {
        hijos.remove(componente);
    }

    @Override
    public void mostrar() {
        System.out.println("Carpeta: " + nombre);
        for (Componente hijo : hijos) {
            hijo.mostrar();
        }
    }
}