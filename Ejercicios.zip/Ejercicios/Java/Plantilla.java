import java.util.Scanner;

abstract class BebidaCafeina {
    protected Scanner sc = new Scanner(System.in);

    public void prepararReceta() {
        hervir();
        preparar();
        verter();

        if(condimentos()) {
            agregar();
        }
    }

    public void hervir() {
        System.out.println("Hirviendo agua");
    }

    public void verter() {
        System.out.println("Vertiendo en la taza");
    }

    public abstract void preparar();

    public abstract void agregar();

    public abstract boolean condimentos();
}

class Te extends BebidaCafeina {
    @Override
    public void preparar() {
        System.out.println("Sumergiendo la bolsa de te en agua caliente");
    }

    @Override
    public void agregar() {
        System.out.println("Añadiendo limón");
    }

    @Override
    public boolean condimentos() {
        System.out.println("Desea agregar limón a su té (si/no)");
        String respuesta = sc.nextLine();
        return respuesta.equalsIgnoreCase("si");
    }
}

class Cafe extends BebidaCafeina {
    @Override
    public void preparar() {
        System.out.println("Pasando el agua a traves del filtro de cafe");
    }

    @Override
    public void agregar() {
        System.out.println("Añadiendo azúcar y leche");
    }

    @Override
    public boolean condimentos() {
        System.out.println("Desea agregar azucar y leche a su café (si/no)");
        String respuesta = sc.nextLine();
        return respuesta.equalsIgnoreCase("si");
    }
}