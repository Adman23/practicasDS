interface Coffee {
    String serve();
}

interface Snack {
    String serve();
}

class Espresso implements Coffee {
    public String serve() {
        return "Serving an Espresso";
    }
}

class Capuccino implements Coffee {
    public String serve() {
        return "Serving a Capuccino";
    }
}

class Croissant implements Snack {
    public String serve() {
        return "Serving a Croissant";
    }
}

class Biscuit implements Snack {
    public String serve() {
        return "Serving a Biscuit";
    }
}

interface CoffeeShopFactory {
    Coffee createCoffee();
    Snack createSnack();
}

class EspressoFactory implements CoffeeShopFactory {
    @Override
    public Coffee createCoffee() {
        return new Espresso();
    }

    @Override
    public Snack createSnack() {
        return new Biscuit();
    }
}

class CapuccinoFactory implements CoffeeShopFactory {
    @Override
    public Coffee createCoffee() {
        return new Capuccino();
    }

    @Override
    public Snack createSnack() {
        return new Croissant();
    }
}