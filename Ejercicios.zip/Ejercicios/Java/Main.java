
public class Main {
    public static void main(String[] args) {
        /* -=+=- PATRÓN SINGLETON -=+=-
        Singleton machine1 = Singleton.getInstance("Latte");
        Singleton machine2 = Singleton.getInstance("Espresso");
        System.out.println(machine1 == machine2);
        System.out.println(machine2.prepare());
        */
        
        /* -=+=- PATRÓN ABSTRACT FACTORY -=+=-
        CoffeeShopFactory factory = new CapuccinoFactory();
        Coffee coffee = factory.createCoffee();
        Snack snack = factory.createSnack();
        System.out.println(coffee.serve());
        System.out.println(snack.serve());
        */

        /* -=+=- PATRÓN FACTORY METHOD -=+=- 
        CoffeeFactory factory = new CoffeeFactory();
        Coffee2 espresso = factory.getCoffee("espresso");
        System.out.println(espresso.serve());

        Coffee2 capuccino = factory.getCoffee("capuccino");
        System.out.println(capuccino.serve());
        */

        /* -=+=- PATRÓN PROTOTIPO -=+=- 
        HumanDNA originalDNA = new HumanDNA();
        HumanDNA assignedDNA = originalDNA;
        HumanDNA clonedDNA = originalDNA.clone();

        originalDNA.mutateGeneticCode("AGT");
        clonedDNA.mutateGeneticCode("CTA");

        System.out.println(originalDNA);
        System.out.println(assignedDNA);
        System.out.println(clonedDNA);
        */

        /* -=+=- PATRÓN BUILDER -=+=- 
        ComputerBuilder gamingBuilder = new GamingComputerBuilder();
        Director director = new Director(gamingBuilder);
        director.buildComputer();
        System.out.println(gamingBuilder.computer.toString());

        ComputerBuilder officeBuilder = new OfficeComputerBuilder();
        Director director2 = new Director(officeBuilder);
        director2.buildComputer();
        System.out.println(officeBuilder.computer.toString());
        */

        /* -=+=- PATRÓN FACHADA -=+=- 
        Fachada interfaz = new Fachada();
        interfaz.procesarOrden(50, 684420039, 50, "Alicante, SantaPola, Calle Haydn Nº 25" );
        */

        /* -=+=- PATRÖN COMPOSITE -=+=- 
        Archivo primero = new Archivo("primero.txt");
        Archivo segundo = new Archivo("segundo.txt");
        Archivo tercero = new Archivo("tercero.txt");
        Archivo cuarto = new Archivo("cuarto.txt");

        Carpeta gloabl = new Carpeta("global");
        gloabl.agregar(primero);
        gloabl.agregar(segundo);
        gloabl.agregar(tercero);
        gloabl.agregar(cuarto);

        gloabl.mostrar();
        */

        /* -=+=- PATRÓN DECORADOR -=+=- 
        Texto nuevo = new TextoSimple("Hola que tal");
        TextoDecorator nuevo_decorado = new TextoNegrita(nuevo);
        System.out.println(nuevo.darFormato());
        System.out.println(nuevo_decorado.darFormato());
        */

        /* -=+=- PATRÓN ADAPTADOR -=+=- 
        ServicioImperial adaptee = new ServicioImperial(36);
        IServicioMetrico adaptador = new AdaptadorTemperatura(adaptee);
        System.out.println("T en Celcius: " + adaptador.obtenerTemperatura());
        */

        /* -=+=- PATRÓN OBSERVADOR -=+=- 
        TemperatureSensor sensor = new TemperatureSensor();
        TemperatureDisplay display = new TemperatureDisplay();
        TemperatureAlertSystem alert_system = new TemperatureAlertSystem();

        sensor.registerObserver(display);
        sensor.registerObserver(alert_system);

        sensor.setTemperature(25);
        sensor.setTemperature(30);
        sensor.setTemperature(35);
        */

        /* -=+=- PATRÓN STRATEGY-=+=- 
        Contexto contexto = new Contexto(new Quicksort());
        ArrayList<Integer> lista = new ArrayList<>();
        lista.add(5);
        lista.add(2);
        lista.add(8);
        lista.add(1);
        lista.add(4);
        System.out.println("Lista ordenada QUICKSORT: " + contexto.ordenar(lista));
        System.out.println("Lista original: " + lista);
        contexto.setStrategy(new Bubblesort());
        System.out.println("Lista ordenada BUBBLESORT: " + contexto.ordenar(lista));
        System.out.println("Lista original: " + lista);
        contexto.setStrategy(new InsertionSort());
        System.out.println("Lista ordenada INSERTIONSORT: " + contexto.ordenar(lista));
        System.out.println("Lista original: " + lista);
        */

        /* -=+=- PATRÓN PLANTILLA -=+=- 
        Te tea = new Te();
        tea.prepararReceta();

        Cafe cafe = new Cafe();
        cafe.prepararReceta();
        */

        /* -=+=- PATRÓN FILTRO -=+=- */
        ChatTarget chatTarget = new ChatTarget();
        FilterManager filterManager = new FilterManager(chatTarget);
        filterManager.addFilter(new SanitizeFilter());
        filterManager.addFilter(new ProhibitedWordsFilter());

        Client client = new Client(filterManager);
        client.sendMessage("Hi <Brown>. Your dog is silly and a garbage");
    }
}

