interface IServicioMetrico {
    double obtenerTemperatura();
}

class ServicioImperial {
    private double temperaturaFarenheit;

    public ServicioImperial(double temperaturaFarenheit) {
        this.temperaturaFarenheit = temperaturaFarenheit;
    }

    public double obtenerTemperaturaFarenheit() {
        return temperaturaFarenheit;
    }
}

class AdaptadorTemperatura implements IServicioMetrico {
    private ServicioImperial adaptee;

    public AdaptadorTemperatura(ServicioImperial adaptee) {
        this.adaptee = adaptee;
    }

    public double obtenerTemperatura() {
        return (adaptee.obtenerTemperaturaFarenheit() -32) * 5/9;
    }
}