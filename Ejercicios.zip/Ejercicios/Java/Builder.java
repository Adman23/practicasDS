class Computer {
    private String processor;
    private String memory;
    private String disk;
    private String graphics_card;

    Computer() {
        this.processor = "";
        this.memory = "";
        this.disk = "";
        this.graphics_card = "";
    }

    public void setProcessor(String processor) {
        this.processor = processor;
    }

    public void setMemory(String memory) {
        this.memory = memory;
    }

    public void setDisk(String disk) {
        this.disk = disk;
    }

    public void setGraphicsCard(String graphics_card) {
        this.graphics_card = graphics_card;
    }

    public String toString() {
        return ("Computer specs:\n Processor: " + this.processor + "\n Memory: " + this.memory + "\n Disk: " + this.disk + "\n Graphics Card: " + this.graphics_card);
    }
}

abstract class ComputerBuilder {
    protected Computer computer;

    public void create_new_computer() {
        this.computer = new Computer();
    }

    public abstract void add_processor();
    public abstract void add_memory();
    public abstract void add_disk();
    public abstract void add_graphics_card();
}

class Director {
    private ComputerBuilder builder;

    Director(ComputerBuilder builder) {
        this.builder = builder;
    }

    public void buildComputer() {
        builder.create_new_computer();
        builder.add_processor();
        builder.add_memory();
        builder.add_disk();
        builder.add_graphics_card();
    }
}

class GamingComputerBuilder extends ComputerBuilder {
    @Override
    public void add_processor() {
        computer.setProcessor("Intel i9");
    }

    @Override
    public void add_memory() {
        computer.setMemory("32GB");
    }

    @Override
    public void add_disk() {
        computer.setDisk("1TB SSD");
    }

    @Override
    public void add_graphics_card() {
        computer.setGraphicsCard("NVIDIA RTX 3080");
    }
}

class OfficeComputerBuilder extends ComputerBuilder {
    @Override
    public void add_processor() {
        computer.setProcessor("Intel i5");
    }

    @Override
    public void add_memory() {
        computer.setMemory("16GB");
    }

    @Override
    public void add_disk() {
        computer.setDisk("500GB SSD");
    }

    @Override
    public void add_graphics_card() {
        computer.setGraphicsCard("Integrated");
    }
}

