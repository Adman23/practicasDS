import java.util.ArrayList;

class Message {
    String content;
    public Message(String content) {
        this.content = content;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}

interface Filter {
    void execute(Message message);
}

class SanitizeFilter implements Filter {
    public void execute(Message message) {
        message.setContent(message.getContent().replace("<", "").replace(">", ""));
    }
}

class ProhibitedWordsFilter implements Filter {
    public void execute(Message message) {
        String[] prohibitedWords = {"silly", "garbage"};
        String content = message.getContent();
        for (String word: prohibitedWords) {
            content = content.replace(word, "[censored]");
        }
        message.setContent(content);
    }
}

class FilterChain {
    private ArrayList<Filter> filters = new ArrayList<>();
    private ChatTarget target;

    public void addFilter(Filter filter) {
        filters.add(filter);
    }

    public void setTarget(ChatTarget target) {
        this.target = target;
    }

    public void execute(Message message) {
        for (Filter filter : filters) {
            filter.execute(message);
        }
        if (target != null) {
            target.publish(message);
        }
    }
}

class ChatTarget {
    public void publish(Message message) {
        System.out.println("Publishing to chat: " + message.getContent());
    }
}

class FilterManager {
    private FilterChain filterChain;

    public FilterManager(ChatTarget target) {
        filterChain = new FilterChain();
        filterChain.setTarget(target);
    }

    public void addFilter(Filter filter) {
        filterChain.addFilter(filter);
    }

    public void postMessage(Message message) {
        filterChain.execute(message);
    }
}

class Client {
    private FilterManager filterManager;

    public Client(FilterManager filterManager) {
        this.filterManager = filterManager;
    }

    public void sendMessage(String content) {
        Message message = new Message(content);
        filterManager.postMessage(message);
    }
}