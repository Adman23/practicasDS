interface Texto {
    String darFormato();
}

class TextoSimple implements Texto {
    private String texto;

    public TextoSimple(String texto) {
        this.texto = texto;
    }

    @Override
    public String darFormato() {
        return texto;
    }
}

abstract class TextoDecorator implements Texto {
    protected Texto textoDecorado;

    public TextoDecorator(Texto texto) {
        this.textoDecorado = texto;
    }

    public String darFormato() {
        return textoDecorado.darFormato();
    }
}

class TextoNegrita extends TextoDecorator {
    public TextoNegrita(Texto texto) {
        super(texto);
    }

    @Override
    public String darFormato() {
        return "<b>" + super.darFormato() + "</b>";
    }
}