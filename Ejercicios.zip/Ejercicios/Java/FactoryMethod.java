abstract class Coffee2 {
    protected String size, milk, intensity;
    public abstract String serve();
}

class Espresso2 extends Coffee2 {
    public Espresso2() {
        size = "small";
        milk = "none";
        intensity = "strong";
    }

    @Override
    public String serve() {
        return "Serving a " + size + " espresso with " +  intensity + " intensity";
    }
}

class Capuccino2 extends Coffee2 {
    public Capuccino2() {
        size = "medium";
        milk = "whole";
        intensity = "regular";
    }

    @Override
    public String serve() {
        return "Serving a " + size + " capuccino with " +  milk + " milk";
    }
}

class CoffeeFactory {
    public static Coffee2 getCoffee(String coffeeType) {
        switch(coffeeType) {
            case "espresso":
                return new Espresso2();
            case "capuccino":
                return new Capuccino2();
            default:
                throw new IllegalArgumentException("Unknown coffee");
        }
    }
}
