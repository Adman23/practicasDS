import java.util.ArrayList;

interface Ordenacion {
    public ArrayList<Integer> ordenar(ArrayList<Integer> array);
}

class Quicksort implements Ordenacion {
    @Override
    public ArrayList<Integer> ordenar(ArrayList<Integer> array) {
        // Crear una copia para no modificar el original
        ArrayList<Integer> copy = new ArrayList<>(array);

        if (copy.size() <= 1) {
            return copy;
        }

        int pivot = copy.get(copy.size() / 2);
        ArrayList<Integer> left = new ArrayList<>();
        ArrayList<Integer> right = new ArrayList<>();

        for (int i = 0; i < copy.size(); i++) {
            if (i == copy.size() / 2) continue;
            if (copy.get(i) < pivot) {
                left.add(copy.get(i));
            } else {
                right.add(copy.get(i));
            }
        }

        ArrayList<Integer> sortedArray = new ArrayList<>();
        sortedArray.addAll(ordenar(left));
        sortedArray.add(pivot);
        sortedArray.addAll(ordenar(right));
        return sortedArray;
    }
}

class Bubblesort implements Ordenacion {
    @Override
    public ArrayList<Integer> ordenar(ArrayList<Integer> array) {
        ArrayList<Integer> copy = new ArrayList<>(array);

        for (int i = 0; i < copy.size() - 1; i++) {
            for (int j = 0; j < copy.size() - 1 - i; j++) {
                if (copy.get(j) > copy.get(j + 1)) {
                    int temp = copy.get(j);
                    copy.set(j, copy.get(j + 1));
                    copy.set(j + 1, temp);
                }
            }
        }

        return copy;
    }
}

class InsertionSort implements Ordenacion {
    @Override
    public ArrayList<Integer> ordenar(ArrayList<Integer> array) {
        ArrayList<Integer> copy = new ArrayList<>(array);

        for (int i = 1; i < copy.size(); i++) {
            int key = copy.get(i);
            int j = i - 1;
            while (j >= 0 && copy.get(j) > key) {
                copy.set(j + 1, copy.get(j));
                j--;
            }
            copy.set(j + 1, key);
        }

        return copy;
    }
}

class Contexto {
    private Ordenacion ordenacion;

    public Contexto(Ordenacion ordenacion) {
        this.ordenacion = ordenacion;
    }

    public void setStrategy(Ordenacion ordenacion) {
        this.ordenacion = ordenacion;
    }

    public ArrayList<Integer> ordenar(ArrayList<Integer> array) {
        return this.ordenacion.ordenar(array);
    }
}
