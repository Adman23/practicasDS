import java.util.ArrayList;

interface TemperatureObserver {
    public void update(double temperature);
}

interface Subject {
    public void registerObserver(TemperatureObserver observer);
    public void removeObserver(TemperatureObserver observer);
    public void notifyObservers();
}

class TemperatureSensor implements Subject {
    private ArrayList<TemperatureObserver> observers = new ArrayList<>();
    private double temperature;

    public void setTemperature(double temperature) {
        this.temperature = temperature;
        notifyObservers();
    }

    @Override
    public void registerObserver(TemperatureObserver observer) {
        this.observers.add(observer);
    }

    @Override
    public void removeObserver(TemperatureObserver observer) {
        this.observers.remove(observer);
    }

    @Override
    public void notifyObservers() {
        for (TemperatureObserver observer: observers) {
            observer.update(this.temperature);
        }
    }
}

class TemperatureDisplay implements TemperatureObserver {
    @Override
    public void update(double temperature) {
        System.out.println("Display: Temperature is now " + temperature + "C");
    }
}

class TemperatureAlertSystem implements TemperatureObserver {
    @Override
    public void update(double temperature) {
        if (temperature > 30) {
            System.out.println("Alert: The temperature is above 30C");
        }
    }
}