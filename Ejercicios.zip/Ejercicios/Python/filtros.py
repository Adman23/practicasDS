from abc import ABC, abstractmethod
class Message:
    def __init__(self, content: str):
        self.content = content
    
    def getContent(self):
        return self.content
    
    def setContent(self, content: str):
        self.content = content

class Filter:
    @abstractmethod
    def execute(self, message: Message):
        pass

class SanitizeFilter(Filter):
    def execute(self, message: Message):
        message.setContent(message.getContent().replace("<", "").replace(">",""))

class ProhibitedWordsFilter(Filter):
    def execute(self, message: Message):
        prohibited_words = ["silly", "garbage"]
        content = message.getContent()
        for word in prohibited_words:
            content = content.replace(word, "[censored]")
        message.setContent(content)

class ChatTarget:
    def publish(self, message: Message):
        print(f"Publishing to chat: {message.getContent()}")

class FilterChain:
    def __init__(self):
        self.filters = []
        self.target = ChatTarget()
    
    def addFilter(self, filter: Filter):
        self.filters.append(filter)
    
    def setTarget(self, target: ChatTarget):
        self.target = target
    
    def execute(self, message: Message):
        for filter in self.filters:
            filter.execute(message)
        if self.target != None:
            self.target.publish(message)

class FilterManager:
    def __init__(self, target: ChatTarget):
        self.filterChain = FilterChain()
        self.filterChain.setTarget(target)
    
    def addFilter(self, filter: Filter):
        self.filterChain.addFilter(filter)
    
    def postMessage(self, message: Message):
        self.filterChain.execute(message)

class Client:
    def __init__(self, filterManager: FilterManager):
        self.filterManager = filterManager
    
    def sendMessage(self, content: str):
        message = Message(content)
        self.filterManager.postMessage(message)




        