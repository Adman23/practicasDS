class CoffeeMachine:
    _instance = None # Atributo privado que guarda la instancia única

    def __new__(cls, *args, **kwargs): # Método estático (se ejecuta antes del __init__) que crea y retorna una nueva instancia de la clase
        if cls._instance is None: # cls es la clase que se está instanciando, comprueba si ya existe una instancia
            cls._instance = super().__new__(cls) # si no existe, se crea
        return cls._instance
    
    def __init__(self, coffee_type):
        if not hasattr(self, 'initialized'):
            self.coffee_type = coffee_type
            self.initialized = True
    
    def brew(self):
        return f"Brewing a {self.coffee_type}"


