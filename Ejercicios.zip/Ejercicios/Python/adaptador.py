from abc import ABC, abstractmethod

class IServicioMetrico:
    @abstractmethod
    def obtenerTemperatura(self):
        pass

class ServicioImperial:
    def __init__(self, temperatura_farenheit):
        self.temperatura_farenheit = temperatura_farenheit

    def obtenerTemperaturaFarenheit(self):
        return self.temperatura_farenheit

class AdaptadorTemperatura(IServicioMetrico):
    def __init__(self, adaptee):
        self.adaptee = adaptee
    
    def obtenerTemperatura(self):
        return (self.adaptee.obtenerTemperaturaFarenheit() -32)*5/9;

