from typing import List
from abc import ABC, abstractmethod

class Componente(ABC):
    @abstractmethod
    def mostrar(self): pass

class Archivo(Componente):
    def __init__(self, nombre: str):
        self.nombre = nombre
    
    def mostrar(self):
        print(f"Archivo: {self.nombre}")

class Carpeta(Componente):
    def __init__(self, nombre: str):
        self.nombre = nombre
        self.hijos: List[Componente] = []  
    
    def agregar(self, componente: Componente):
        self.hijos.append(componente)
    
    def remover(self, componente: Componente):
        self.hijos.remove(componente) 
    
    def mostrar(self):
        print(f"Carpeta: {self.nombre}")
        for hijo in self.hijos:
            hijo.mostrar()
