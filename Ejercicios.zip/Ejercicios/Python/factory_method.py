class Coffee:
    def __init__(self, size="medium", milk="none", intensity="regular"):
        self.size = size
        self.milk = milk
        self.intensity = intensity
    
    def serve(self):
        descripcion = f"{self.size} {self.intensity}"
        if self.milk != "none":
            descripcion += f" with {self.milk} milk"
        return f"Serving a cup of {descripcion} coffee"

class Espresso(Coffee):
    def __init__(self, milk="none"):
        super().__init__(size="small", intensity="strong", milk = milk)

class Capuccino(Coffee):
    def __init__(self, size="medium", intensity="regular"):
        super().__init__(size=size, milk="whole", intensity=intensity)

class Americano(Coffee):
    def __init__(self, size="large", intensity="light"):
        super().__init__(size=size, milk="none", intensity=intensity)

class CoffeeFactory:
    def get_coffee(self, coffee_type, size="medium", milk="none", intensity="regular"):
        if coffee_type == "espresso":
            return Espresso(milk=milk)
        elif coffee_type == "cappuccino":
            return Capuccino(size=size, intensity=intensity)
        elif coffee_type== "americano":
            return Americano(size=size, intensity=intensity)
        else:
            raise ValueError("Incorrect coffee type")