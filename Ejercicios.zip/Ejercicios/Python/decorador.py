from abc import ABC, abstractmethod

class Texto(ABC):
    @abstractmethod
    def dar_formato(self):
        pass

class TextoSimple(Texto):
    def __init__(self, texto):
        self.texto = texto
    
    def dar_formato(self):
        return self.texto

class TextoDecorator(Texto):
    def __init__(self, texto):
        self.texto_decorado = texto
    
    def dar_formato(self):
        return self.texto_decorado.dar_formato()

class TextoNegrita(TextoDecorator):
    def dar_formato(self):
        return f"<b>{self.texto_decorado.dar_formato()}</b>"

class TextoCursiva(TextoDecorator):
    def dar_formato(self):
        return f"<i>{self.texto_decorado.dar_formato()}</i>"
