import copy

class HumanDNA:
    def __init__(self):
        self.genetic_code = []
    
    def clone(self):
        return copy.deepcopy(self)
    
    def mutate_genetic_code(self, mutation):
        self.genetic_code.append(mutation);

    def __str__(self):
        return f"Genetic Code: {self.genetic_code}"