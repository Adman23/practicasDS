class SistemaInventario:
    def verificar_disponibilidad(self, producto_id):
        print(f"Verificando la disp. de {producto_id}")
        return True

class SistemaPagos:
    def procesar_pago(self, tarjeta_numero, monto):
        print(f"Pago con tarjeta {tarjeta_numero}, {monto}")
        return True

class SistemaEnvios:
    def programar_envio(self, direccion):
        print(f"Programando envio a {direccion}")
        return True

class Fachada:
    def __init__(self):
        self.inventario = SistemaInventario()
        self.pagos = SistemaPagos()
        self.envios = SistemaEnvios()

    def procesar_orden(self, producto_id, tarjeta_numero, monto, direccion):
        if self.inventario.verificar_disponibilidad(producto_id):
            if self.pagos.procesar_pago(tarjeta_numero, monto):
                self.envios.programar_envio(direccion)
                print("Orden procesada exitosamente")
            else:
                print("El pago no puede ser procesado")
        else:
            print("Producto no disponible")