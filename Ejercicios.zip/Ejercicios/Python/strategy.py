from abc import ABC, abstractmethod

class Ordenacion:
    @abstractmethod
    def ordenar(self, array):
        pass

class Quicksort(Ordenacion):
    def ordenar(self, array):
        if len(array) <= 1:
            return array
        pivot = array[len(array) // 2]
        left = [x for x in array if x < pivot]
        middle = [x for x in array if x == pivot]
        right = [x for x in array if x > pivot]
        return self.ordenar(left) + middle + self.ordenar(right)

class Bubblesort(Ordenacion):
    def ordenar(self, array):
        n = len(array)
        for i in range(n):
            for j in range(0, n-i-1):
                if array[j] > array[j+1]:
                    array[j], array[j+1] = array[j+1], array[j]
        return array

class InsertionSort(Ordenacion):
    def ordenar(self, array):
        for i in range(1, len(array)):
            key = array[i]
            j = i-1
            while j >= 0 and key < array[j]:
                array[j + 1] = array[j]
                j -= 1
            array[j + 1] = key
        return array

class Contexto:
    def __init__(self, estrategia: Ordenacion):
        self._estrategia = estrategia

    def set_estrategia(self, estrategia: Ordenacion):
        self._estrategia = estrategia

    def ordenar(self, array):
        return self._estrategia.ordenar(array)