from singleton import *
from abstract_factory import *
from factory_method import *
from prototipo import *
from builder import *
from fachada import *
from composite import *
from decorador import *
from adaptador import *
from observador import *
from strategy import *
from plantilla import *
from filtros import *

def main():
    
    #-=+=- PATRÓN SINGLETON -=+=-
    # machine1 = CoffeeMachine("latte")
    # machine2 = CoffeeMachine("espresso")

    # print(machine1.brew())
    # print(machine2.brew())
    # print(machine1 is machine2)

    #-=+=- PATRÓN ABSTRACT FACTORY -=+=-
    # factory = CapuccinoFactory()
    # coffee = factory.create_coffee()
    # snack = factory.create_snack()

    # print(coffee.serve())
    # print(snack.serve())

    #-=+=- PATRÓN FACTORY METHOD -=+=-
    # factory = CoffeeFactory()
    # espresso = factory.get_coffee("espresso")
    # print(espresso.serve())

    # cappuccino = factory.get_coffee("cappuccino")
    # print(cappuccino.serve())

    # americano = factory.get_coffee("americano")
    # print(americano.serve())

    #-=+=- PATRÓN PROTOTIPO -=+=-
    # dna1 = HumanDNA()
    # dna1.mutate_genetic_code("A->T")
    # dna1.mutate_genetic_code("G->C")

    # print(dna1)

    # dna2 = dna1.clone()
    # dna2.mutate_genetic_code("T->G")

    # print(dna2)
    # print(dna1)

    #-=+=- PATRÓN BUILDER -=+=-
    # gaming_builder = GamingComputerBuilder()
    # director = Director(gaming_builder)
    # director.build_computer()
    # print(gaming_builder.computer)

    # office_builder = OfficeComputerBuilder()
    # director = Director(office_builder)
    # director.build_computer()
    # print(office_builder.computer)

    # -=+=- PATRÓN FACHADA -=+=-
    # interfaz = Fachada()
    # interfaz.procesar_orden(50, 684420039, 100, "Alicante, SantaPola, Calle Haydn Nº25")

    # -=+=- PATRÓN COMPOSITE -=+=-
    # primero = Archivo("primero.txt")
    # segundo = Archivo("segundo.txt")
    # tercero = Archivo("tercero.txt")
    # cuarto = Archivo("cuarto.txt")

    # directorio = Carpeta("global")
    # directorio.agregar(primero)
    # directorio.agregar(segundo)
    # directorio.agregar(tercero)
    # directorio.agregar(cuarto)

    # directorio.mostrar();

    # -=+=- PATRÓN DECORADOR -=+=-
    # texto = TextoSimple("Hola Mundo")
    # texto_negrita = TextoNegrita(texto)
    # texto_cursiva = TextoCursiva(texto)

    # print(texto.dar_formato());
    # print(texto_negrita.dar_formato());
    # print(texto_cursiva.dar_formato());

    # -=+=- PATRÓN ADAPTADOR -=+=-
    # adaptee = ServicioImperial(36)
    # adaptador = AdaptadorTemperatura(adaptee)
    # print(f"T en Celcius: {adaptador.obtenerTemperatura()}")

    # -=+=- PATRÓN OBSERVADOR -=+=-
    # sensor = TemperatureSensor()
    # display = TemperatureDisplay()
    # alert_system = TemperatureAlertSystem()

    # sensor.register_observer(display)
    # sensor.register_observer(alert_system)

    # sensor.set_temperature(25)
    # sensor.set_temperature(30)
    # sensor.set_temperature(35)

    # -=+=- PATRÓN STRATEGY -=+=-
    # contexto = Contexto(Quicksort())
    # array = [5, 3, 8, 6, 2]
    # print("Array original:", array)
    # sorted_array = contexto.ordenar(array)
    # print("Array ordenado con Quicksort:", sorted_array)

    # contexto.set_estrategia(Bubblesort())
    # sorted_array = contexto.ordenar(array)
    # print("Array ordenado con Bubblesort:", sorted_array)

    # contexto.set_estrategia(InsertionSort())
    # sorted_array = contexto.ordenar(array)
    # print("Array ordenado con InsertionSort:", sorted_array)

    # -=+=- PATRÓN PLANTILLA -=+=-
    # mi_tea = Te()
    # mi_tea.preparar_receta()

    # mi_cafe = Cafe()
    # mi_cafe.preparar_receta()

    # -=+=- PATRÓN FILTRO -=+=-
    chatTarget = ChatTarget()
    filterManager = FilterManager(chatTarget)
    filterManager.addFilter(SanitizeFilter())
    filterManager.addFilter(ProhibitedWordsFilter())

    client = Client(filterManager)
    client.sendMessage("Hi <Brown>. Your dog is silly and a garbage")

    return

if __name__ == "__main__":
    main()
