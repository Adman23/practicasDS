from abc import ABC, abstractmethod

class BebidaCafeina(ABC):
    def preparar_receta(self):
        self.hervir_agua()
        self.preparar_infusion()
        self.verter_en_taza()
        if self.cliente_quiere_condimentos():
            self.agregar_condimentos()
    
    def hervir_agua(self):
        print("Hirviendo agua")
    
    def verter_en_taza(self):
        print("Vertiendo en la taza")
    
    @abstractmethod
    def preparar_infusion(self):
        pass

    @abstractmethod
    def agregar_condimentos(self):
        pass

class Te(BebidaCafeina):
    def preparar_infusion(self):
        print("Sumergiendo la bolsa de te en agua caliente")
    
    def agregar_condimentos(self):
        print("Añadiendo limón")
    
    def cliente_quiere_condimentos(self):
        respuesta = input("Desea agregar limón a su té (si/no)")
        return respuesta.lower() == "si"

class Cafe(BebidaCafeina):
    def preparar_infusion(self):
        print("Pasando el agua a traves del filtro de cafe")
    
    def agregar_condimentos(self):
        print("Añadiendo azúcar y leche")
    
    def cliente_quiere_condimentos(self):
        respuesta = input("Desea agregar azucar y leche a su café (si/no)")
        return respuesta.lower() == "si"