class Director:
    def __init__(self, builder):
        self._builder = builder
    
    def build_computer(self):
        self._builder.create_new_computer()
        self._builder.add_processor()
        self._builder.add_memory()
        self._builder.add_disk()
        if hasattr(self._builder, 'add_graphics_card'):
            self._builder.add_graphics_card()


from abc import ABC, abstractmethod

class Computer:
    def __init__(self):
        self.processor = None
        self.memory = None
        self.disk = None
        self.graphics_card = None

    def __str__(self):
        return f"Computer specs:\n Processor: {self.processor}\n Memory: {self.memory}\n Disk: {self.disk}\n Graphics Card: {self.graphics_card}"

class ComputerBuilder(ABC):
    def __init__(self):
        self.computer = None
    
    def create_new_computer(self):
        self.computer = Computer()
    
    @abstractmethod
    def add_processor(self):
        pass

    @abstractmethod
    def add_memory(self):
        pass

    @abstractmethod
    def add_disk(self):
        pass

    @abstractmethod
    def add_graphics_card(self):
        pass

class GamingComputerBuilder(ComputerBuilder):
    def add_processor(self):
        self.computer.processor = "Intel i9"
    
    def add_memory(self):
        self.computer.memory = "32GB"
    
    def add_disk(self):
        self.computer.disk = "1TB SSD"
    
    def add_graphics_card(self):
        self.computer.graphics_card = "NVIDIA RTX 3080"

class OfficeComputerBuilder(ComputerBuilder):
    def add_processor(self):
        self.computer.processor = "Intel i5"
    
    def add_memory(self):
        self.computer.memory = "16GB"
    
    def add_disk(self):
        self.computer.disk = "500GB SSD"
    
    def add_graphics_card(self):
        self.computer.graphics_card = "Integrated"

