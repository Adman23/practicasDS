from abc import ABC, abstractmethod

class Coffee(ABC):
    @abstractmethod
    def serve(self): pass

class Snack(ABC):
    @abstractmethod
    def serve(self): pass

class Espresso(Coffee):
    def serve(self): return "Serving an Espresso"

class Capuccino(Coffee):
    def serve(self): return "Serving a Capuccino"

class Croissant(Snack):
    def serve(self): return "Serving a Croissant"

class Biscuit(Snack):
    def serve(self): return "Serving a Biscuit"

class CoffeeShopFactory(ABC):
    @abstractmethod
    def create_coffee(self): pass
    
    @abstractmethod
    def create_snack(self): pass

class EspressoFactory(CoffeeShopFactory):
    def create_coffee(self): return Espresso()
    def create_snack(self): return Biscuit()

class CapuccinoFactory(CoffeeShopFactory):
    def create_coffee(self): return Capuccino()
    def create_snack(self): return Croissant()